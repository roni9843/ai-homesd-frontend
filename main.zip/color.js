// color.js
export const primaryColor = "#2ECC71";

export const whiteColor = "#FFFFFF";

export const whiteColor_v_2 = "#F2F2F2"; // background

export const whiteColor_v_3 = "#D9D9D9";

export const grayColor = "#808080";

export const blackColor = "#010002";

export const redColor = "#FF0000";
