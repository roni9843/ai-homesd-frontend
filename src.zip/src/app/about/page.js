export default function SignupPage() {
  return (
    <div>
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugiat enim,
      veritatis natus quia incidunt, assumenda dolore earum iure numquam hic
      magni. Esse aliquam inventore molestiae, nam iusto temporibus in tenetur
      illum? Quos exercitationem repudiandae vitae assumenda, iure ducimus, non
      recusandae saepe veniam magnam officiis qui sint pariatur necessitatibus
      enim itaque unde molestias voluptatibus! Tenetur dolor provident aut
      expedita quod ipsam perspiciatis aliquam, doloribus cum hic quaerat
      corrupti numquam laboriosam vel voluptatem cupiditate, ea ipsum quasi
      laudantium rerum ad. Doloribus explicabo nam voluptates velit impedit
      deserunt esse, alias sequi quae placeat consequuntur illo officia. Error
      tenetur autem eligendi perferendis culpa doloremque amet, laborum, tempore
      ut suscipit cum repellendus alias excepturi minima aperiam earum expedita
      vero quasi architecto, dolor incidunt? Possimus, ipsum voluptates. Ea
      deleniti pariatur suscipit adipisci quam! Asperiores ex accusamus
      voluptatem sequi. Obcaecati soluta officiis esse ipsum unde. Ea, ad totam!
      Animi tenetur cupiditate tempora incidunt ea maiores nostrum eaque sequi
      quam delectus, dignissimos sunt esse voluptatibus soluta laboriosam
      mollitia deserunt, sed nam sapiente aut? Suscipit explicabo reiciendis est
      fugiat consectetur rem, accusamus quisquam similique fuga illo recusandae,
      praesentium voluptas soluta at nihil alias aspernatur deserunt repellendus
      id dicta laudantium aliquid modi aperiam. Ipsa numquam, quaerat cumque
      possimus perspiciatis fugit!
    </div>
  );
}
