"use client";

import CreditScoreIcon from "@mui/icons-material/CreditScore";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import PendingActionsIcon from "@mui/icons-material/PendingActions";
import ViewQuiltIcon from "@mui/icons-material/ViewQuilt";
import { Box, Grid, Typography } from "@mui/material";
import Stack from "@mui/material/Stack";
import Step from "@mui/material/Step";
import StepConnector, {
  stepConnectorClasses,
} from "@mui/material/StepConnector";
import StepLabel from "@mui/material/StepLabel";
import Stepper from "@mui/material/Stepper";
import { styled } from "@mui/material/styles";
import Image from "next/image";
import PropTypes from "prop-types";
import {
  blackColor,
  redColor,
  whiteColor,
  whiteColor_v_3,
} from "../../../color";

const ColorlibConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 22,
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: redColor,
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: redColor,
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: whiteColor_v_3,
    borderRadius: 1,
  },
}));

const ColorlibStepIconRoot = styled("div")(({ theme, ownerState }) => ({
  backgroundColor: ownerState.active ? blackColor : whiteColor_v_3,
  zIndex: 1,
  color: ownerState.active ? whiteColor : blackColor,
  width: 50,
  height: 50,
  display: "flex",
  borderRadius: "50%",
  justifyContent: "center",
  alignItems: "center",
  ...(ownerState.active && {
    backgroundImage: "#eee",
    boxShadow: `0 4px 10px 0 ${blackColor}`,
  }),
  ...(ownerState.completed && {
    backgroundImage: "#eee",
  }),
}));

function ColorlibStepIcon(props) {
  const { active, completed, className } = props;

  const icons = {
    1: <PendingActionsIcon />,
    2: <ViewQuiltIcon />,
    3: <LocalShippingIcon />,
    4: <CreditScoreIcon />,
  };

  return (
    <ColorlibStepIconRoot
      ownerState={{ completed, active }}
      className={className}
    >
      {icons[String(props.icon)]}
    </ColorlibStepIconRoot>
  );
}

ColorlibStepIcon.propTypes = {
  active: PropTypes.bool,
  className: PropTypes.string,
  completed: PropTypes.bool,
  icon: PropTypes.node,
};

const steps = ["Pending", "Processing", "Shipped", "Delivered"];

export default function Order({ orderDetails, userInfo }) {
  console.log("this is order details -> ", orderDetails);

  if (!orderDetails) {
    return <div>No order details available</div>;
  }

  const getActiveStep = (status) => {
    switch (status) {
      case "Pending":
        return 0;
      case "Processing":
        return 1;
      case "Shipped":
        return 2;
      case "Delivered":
        return 3;
      default:
        return 0;
    }
  };

  <style jsx>{`
    @media (min-width: 576px) {
      .product-grid {
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
      }
    }

    @media (min-width: 768px) {
      .product-grid {
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      }
    }

    @media (min-width: 992px) {
      .product-grid {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      }
    }
  `}</style>;

  const truncateString = (str, num) => {
    if (str.length > num) {
      return str.slice(0, num) + "...";
    } else {
      return str;
    }
  };
  return (
    <div style={{ padding: "20px", maxWidth: "1200px", margin: "0 auto" }}>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <div style={{ padding: "10px", textAlign: "center" }}>
          <span style={{ fontSize: "24px" }}>
            Shipping <span style={{ fontWeight: "bold" }}>Information</span>
          </span>
        </div>
        <div style={{ fontSize: "12px", textAlign: "center" }}>
          <span>
            Order date: {new Date(orderDetails.orderDate).toLocaleDateString()}
          </span>
          <br />
          <span>
            Estimated delivery:{" "}
            {new Date(
              new Date(orderDetails.orderDate).setDate(
                new Date(orderDetails.orderDate).getDate() + 7
              )
            ).toLocaleDateString()}
          </span>
          <br />
          <span>
            Order Id:{" "}
            <span style={{ fontWeight: "bold" }}>{orderDetails.orderId}</span>
          </span>
        </div>

        <div
          style={{
            padding: "10px",
            margin: "10px",
            backgroundColor: whiteColor_v_3,
            borderRadius: "5px",
            fontSize: "13px",
            width: "100%",
            boxSizing: "border-box",
          }}
        >
          <div>
            <span style={{ fontSize: "15px", fontWeight: "bold" }}>
              Order Details
            </span>
          </div>
          <div>
            <span>Name: {userInfo.username}</span>
          </div>

          <div>
            <span>Phone: {userInfo.phoneNumber}</span>
          </div>
          <div>
            <span>Address: {orderDetails.address}</span>
          </div>
          <div>
            <span style={{ fontWeight: "bold" }}>
              Payment Method: {orderDetails.paymentMethod}
            </span>
          </div>
          <div
            style={{
              //textAlign: "left",
              fontWeight: "bold",
              fontSize: "15px",
              marginTop: "20px",
            }}
          >
            Total: ৳{orderDetails.totalAmount}
          </div>
        </div>
      </div>

      {orderDetails.status === "Cancelled" ? (
        <div style={{ textAlign: "center", color: redColor }}>
          This order was Cancelled
        </div>
      ) : (
        <Stack sx={{ width: "100%" }} spacing={4}>
          <Stepper
            alternativeLabel
            activeStep={getActiveStep(orderDetails.status)}
            connector={<ColorlibConnector />}
          >
            {steps.map((label, index) => (
              <Step key={label}>
                <StepLabel
                  StepIconComponent={ColorlibStepIcon}
                  StepIconProps={{ icon: index + 1 }}
                >
                  {label}
                </StepLabel>
              </Step>
            ))}
          </Stepper>
        </Stack>
      )}

      <Box sx={{ padding: "20px", maxWidth: "1000px", margin: "0 auto" }}>
        <Grid container spacing={3}>
          {orderDetails.products.map((item, index) => (
            <Grid item xs={12} sm={12} md={4} lg={3} key={index}>
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  backgroundColor: "#f7f7f7",
                  borderRadius: "8px",
                  boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                  padding: "16px",
                  transition: "transform 0.2s",
                  "&:hover": { transform: "scale(1.05)" },
                }}
              >
                <Image
                  unoptimized
                  src={item.product.images[0]}
                  alt={item.product.productName}
                  height={100}
                  width={100}
                  style={{
                    objectFit: "cover",
                    borderRadius: "8px",
                    marginRight: "16px",
                  }}
                />
                <Box sx={{ textAlign: "left", flexGrow: 1 }}>
                  <Typography
                    variant="h6"
                    sx={{ fontSize: "16px", fontWeight: 500 }}
                  >
                    {truncateString(item.product.productName, 10)}
                  </Typography>

                  {/* Display Quantity */}
                  <Typography sx={{ fontSize: "14px", color: "#555" }}>
                    Qty: {item.qty}
                  </Typography>

                  {/* Highlight Discount if Offer Exists */}
                  {item.product.productOffer > 0 && (
                    <Typography
                      sx={{
                        fontSize: "14px",
                        fontWeight: "bold",
                        color: "red", // Highlight the discount in red
                        marginBottom: "4px",
                      }}
                    >
                      {item.product.productOffer}% OFF
                    </Typography>
                  )}

                  {/* Product Price */}
                  <Typography
                    variant="h5"
                    sx={{ fontWeight: "bold", color: "#333", marginTop: "4px" }}
                  >
                    {item.product.productOffer > 0 ? (
                      <Box>
                        {/* Show Regular Price with strikethrough */}
                        <Typography
                          sx={{
                            textDecoration: "line-through",
                            fontSize: "14px",
                            color: "#888",
                          }}
                        >
                          ৳{item.product.productRegularPrice.toFixed(2)}
                        </Typography>

                        {/* Show Discounted Price */}
                        <span>
                          ৳
                          {(
                            item.product.productRegularPrice.toFixed(2) *
                            (1 - item.product.productOffer / 100)
                          ).toFixed(2)}
                        </span>
                      </Box>
                    ) : (
                      <span>
                        ৳{item.product.productRegularPrice.toFixed(2)}
                      </span>
                    )}
                  </Typography>
                </Box>
              </Box>
            </Grid>
          ))}
        </Grid>
      </Box>
    </div>
  );
}

Order.propTypes = {
  orderDetails: PropTypes.shape({
    orderDate: PropTypes.string.isRequired,
    orderId: PropTypes.string.isRequired,
    status: PropTypes.string.isRequired,
    totalAmount: PropTypes.number.isRequired,
    paymentMethod: PropTypes.string.isRequired,
    address: PropTypes.string.isRequired,
    products: PropTypes.arrayOf(
      PropTypes.shape({
        product: PropTypes.shape({
          productName: PropTypes.string.isRequired,
          productRegularPrice: PropTypes.number.isRequired,
          images: PropTypes.arrayOf(PropTypes.string).isRequired,
        }).isRequired,
        qty: PropTypes.number.isRequired,
      })
    ).isRequired,
  }),
};
