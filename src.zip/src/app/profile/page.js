import ProfilePageState from "./ProfilePageState";

export default function page() {
  return (
    <div>
      <ProfilePageState></ProfilePageState>
    </div>
  );
}
